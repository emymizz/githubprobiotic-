import numpy as np
import pandas as pd

DATASET_FILEPATH = "C:\\Users\\IDEAPAD\Desktop\\Feature_Subset_Selection_Genetic_Algorithm-master\\DATASETS\\probiotic\\fyp data analysis.csv"
DATASET = pd.read_csv(DATASET_FILEPATH)
DATASET_t = DATASET.T

print(DATASET_T)
DATASET_t.to_csv('fyp data analysis.csv')





