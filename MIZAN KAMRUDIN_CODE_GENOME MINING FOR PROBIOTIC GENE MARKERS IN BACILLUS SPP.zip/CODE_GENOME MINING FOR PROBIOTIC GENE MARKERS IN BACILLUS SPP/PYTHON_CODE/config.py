#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 30 21:13:38 2017

@author: rahul
"""

VERSION = 'fyp data analysis_RemovedIdenticalLatest'

DATASET_FILEPATH = "C:\\Users\\IDEAPAD\\Desktop\\Feature_Subset_Selection_Genetic_Algorithm-master\\DATASETS\probiotic\\fyp data analysis_RemovedIdenticalLatest.csv"

OUTPUT_FILEPATH = DATASET_FILEPATH[:-4] + "_output.txt"

NUM_FEATURES = 124
POPULATION_SIZE = 10
EQDE_MAXITER = 1000
ELITISM = 0.999

F = 0.5
CR = 0.5

TEST_SIZE = 0.3
